# NIME20_Music_Proceedings_Template
Music Proceedings LaTeX and Word template for the NIME 2020 International Conference

Link to word template: https://drive.google.com/open?id=1nHjcQDBs5MMB7Ke1Uz4IYmAA8nbcHt8S

## Questions

1. Do we want to keep the keywords in the template for the artistic submissions? If so we need to add them also to the word template.